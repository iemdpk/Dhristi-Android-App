import kivy
from kivy.app import App
from kivy.lang import Builder
from kivy.core.window import Window
from kivy.utils import get_color_from_hex
from kivy.uix.gridlayout import GridLayout
from kivy.properties import ObjectProperty
import json
import requests

class Deepak(GridLayout):

	name = ObjectProperty(None)
	email = ObjectProperty(None)
	number = ObjectProperty(None)
	orga = ObjectProperty(None)
	url = 'https://dhristi-72fe6.firebaseio.com/.json'

	def btn(self,JSON):
		deepak = {}

		deepak[self.name.text] = {
		'email' : self.email.text,
		'number' : self.number.text,
		'Organisation' : self.orga.text
		}
		s = json.dumps(deepak)
		print(s)
		data = json.loads(s)
		requests.patch(url = self.url , json = data)

		
		
		

	pass
		

class Dhristi(App):
	def build(self):
		title = "Dhristi"
		Window.clearcolor = get_color_from_hex('#FFFFFF')
		return Deepak() 

if __name__ == "__main__":
	Dhristi().run()