import kivy
from kivy.app import App
from kivy.lang import Builder
from kivy.core.window import Window
from kivy.utils import get_color_from_hex
from kivy.uix.gridlayout import GridLayout
from kivy.properties import ObjectProperty
from kivy.uix.label import Label
import json
import requests
from kivy.uix.popup import Popup

class Deepak(GridLayout):

	name = ObjectProperty(None)
	email = ObjectProperty(None)
	number = ObjectProperty(None)
	orga = ObjectProperty(None)
	url = 'https://dhristi-72fe6.firebaseio.com/.json'

	def btn(self,JSON):
		deepak = {}
		deepak[self.name.text] = {
		'email' : self.email.text,
		'number' : self.number.text,
		'Organisation' : self.orga.text
		}
		s = json.dumps(deepak)
		data = json.loads(s)
		requests.patch(url = self.url , json = data)

		popup = Popup(title='Thank You So Much',
    	content=Label(text='Our Team will Call You Shortly',font_size= 20),
    	size_hint=(None, None), size=(400, 400)) 
			
		popup.open()
		
		

	pass
		

class Dhristi(App):
	def build(self):
		title = "Dhristi"
		Window.clearcolor = get_color_from_hex('#FFFFFF')
		return Deepak() 

if __name__ == "__main__":
	Dhristi().run()